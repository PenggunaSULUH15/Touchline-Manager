# Match engine

Keep simulation rules independent from Phaser rendering.

Planned modules:
- `matchEngine.js`: authoritative match state and simulation ticks.
- `possession.js`: possession and passing decisions.
- `movement.js`: player positioning and off-ball runs.
- `shooting.js`: shot selection and outcome probabilities.
- `defending.js`: pressure, interceptions, tackles and blocks.
- `events.js`: structured match events for commentary and analytics.

The match engine should emit state snapshots/events. Phaser should render those snapshots and must not decide match outcomes.

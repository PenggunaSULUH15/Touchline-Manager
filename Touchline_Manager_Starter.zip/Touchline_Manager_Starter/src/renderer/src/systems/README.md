# Management systems

Planned modules:
- transfers and contract negotiations
- scouting assignments and reports
- player development and training
- fatigue, morale and injuries
- club finances and board confidence
- league, cup and season scheduling
- youth intake and player retirement
- inbox, news and world simulation

Each system should expose small functions that can be tested without rendering the UI.

import { useEffect, useRef } from "react";
import Phaser from "phaser";

export default function MatchPitch() {
  const host = useRef(null);

  useEffect(() => {
    if (!host.current) return;

    class PitchScene extends Phaser.Scene {
      constructor() { super("Pitch"); }
      create() {
        const { width, height } = this.scale;
        const g = this.add.graphics();
        const margin = 24;
        const x = margin, y = 18, w = width - margin * 2, h = height - 36;

        g.fillStyle(0x174b3b, 1).fillRoundedRect(x, y, w, h, 8);
        g.lineStyle(2, 0xb8d5c6, 0.75).strokeRect(x + 8, y + 8, w - 16, h - 16);
        g.lineBetween(width / 2, y + 8, width / 2, y + h - 8);
        g.strokeCircle(width / 2, height / 2, 48);
        g.strokeRect(x + 8, height / 2 - 85, 90, 170);
        g.strokeRect(x + w - 98, height / 2 - 85, 90, 170);
        g.strokeRect(x + 8, height / 2 - 42, 30, 84);
        g.strokeRect(x + w - 38, height / 2 - 42, 30, 84);

        const home = [[.13,.5],[.27,.22],[.27,.42],[.27,.58],[.27,.78],[.44,.3],[.44,.5],[.44,.7],[.62,.22],[.62,.5],[.62,.78]];
        const away = [[.87,.5],[.73,.22],[.73,.42],[.73,.58],[.73,.78],[.56,.3],[.56,.5],[.56,.7],[.38,.22],[.38,.5],[.38,.78]];
        home.forEach((p,i) => this.add.circle(x + w*p[0], y + h*p[1], 8, 0x60a5fa).setStrokeStyle(2,0xeaf4ff).setDepth(2));
        away.forEach((p,i) => this.add.circle(x + w*p[0], y + h*p[1], 8, 0xf87171).setStrokeStyle(2,0xffeeee).setDepth(2));
        this.add.circle(width/2, height/2, 5, 0xffffff).setStrokeStyle(1,0x172033);
      }
    }

    const game = new Phaser.Game({
      type: Phaser.CANVAS,
      width: 760,
      height: 420,
      parent: host.current,
      backgroundColor: "#102c24",
      scene: PitchScene,
      scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
      render: { antialias: true }
    });

    return () => game.destroy(true);
  }, []);

  return <div className="pitch-host" ref={host} aria-label="Static 2D football pitch preview" />;
}

import { useState } from "react";
import {
  Activity, ArrowLeftRight, Bell, CalendarDays, ChartNoAxesCombined,
  ChevronRight, CircleDollarSign, ClipboardList, Home, Mail,
  Search, Settings, Shield, Trophy, Users, Zap
} from "lucide-react";
import club from "./data/clubs.json";
import players from "./data/players.json";
import MatchPitch from "./components/MatchPitch.jsx";

const nav = [
  ["Overview", Home],
  ["Squad", Users],
  ["Tactics", ClipboardList],
  ["Match Centre", Activity],
  ["Transfers", ArrowLeftRight],
  ["Scouting", Search],
  ["Competitions", Trophy],
  ["Finances", CircleDollarSign],
  ["Inbox", Mail]
];

export default function App() {
  const [page, setPage] = useState("Overview");
  const team = club[0];
  const squad = players.filter(p => p.clubId === team.id);

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><Shield size={21} /></div>
          <div><strong>TOUCHLINE</strong><span>MANAGER</span></div>
        </div>
        <div className="club-switcher">
          <div className="club-crest">NB</div>
          <div><strong>{team.name}</strong><span>First Team</span></div>
          <ChevronRight size={16} />
        </div>
        <div className="nav-label">MANAGEMENT</div>
        <nav>
          {nav.map(([label, Icon]) => (
            <button key={label} className={`nav-item ${page === label ? "active" : ""}`}
              onClick={() => setPage(label)}>
              <Icon size={18} /><span>{label}</span>
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <button className="nav-item"><Settings size={18}/><span>Settings</span></button>
          <div className="manager-card">
            <div className="avatar">MT</div>
            <div><strong>Manager</strong><span>New Career</span></div>
          </div>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="breadcrumb">CLUB / <strong>{page.toUpperCase()}</strong></div>
          <div className="topbar-right">
            <span className="season-tag">2026 / 27</span>
            <button className="icon-button" aria-label="Notifications"><Bell size={18}/></button>
            <div className="date-label"><CalendarDays size={16}/> 11 November 2026</div>
          </div>
        </header>

        <div className="page-content">
          {page === "Overview" ? (
            <>
              <section className="welcome-row">
                <div>
                  <div className="eyebrow">WEDNESDAY, 11 NOVEMBER 2026</div>
                  <h1>Club overview</h1>
                  <p className="muted">Welcome back. Here's what's happening at your club.</p>
                </div>
                <button className="primary-button"><Zap size={16}/> Continue</button>
              </section>

              <section className="club-hero">
                <div className="hero-crest">NB</div>
                <div className="hero-info">
                  <div className="eyebrow">YOUR CLUB</div>
                  <h2>{team.name}</h2>
                  <p>{team.country} <span className="dot-separator">•</span> {team.stadium}</p>
                </div>
                <div className="hero-stat"><span>LEAGUE POSITION</span><strong>—</strong><small>Season not started</small></div>
                <div className="hero-stat"><span>BOARD CONFIDENCE</span><strong>78%</strong><small className="positive">Stable</small></div>
              </section>

              <section className="stat-grid">
                <Stat icon={CircleDollarSign} label="Transfer budget" value={money(team.transferBudget)} detail="Available funds"/>
                <Stat icon={Users} label="First-team squad" value={String(squad.length)} detail="Registered players"/>
                <Stat icon={ChartNoAxesCombined} label="Wage budget" value={money(team.wageBudget)} detail="Weekly allowance"/>
                <Stat icon={Trophy} label="Club reputation" value={`${team.reputation}/100`} detail="National standing"/>
              </section>

              <div className="content-grid">
                <section className="panel">
                  <div className="panel-heading"><div><h3>Next fixture</h3><p className="muted">PRE-SEASON FRIENDLY</p></div><span className="status-pill">UPCOMING</span></div>
                  <div className="fixture">
                    <div className="fixture-team"><div className="fixture-crest">NB</div><strong>Northbridge</strong></div>
                    <div className="fixture-middle"><span>VS</span><small>To be scheduled</small></div>
                    <div className="fixture-team"><div className="fixture-crest opponent">FC</div><strong>Opponent</strong></div>
                  </div>
                  <div className="panel-footer">No fixtures have been generated yet.</div>
                </section>

                <section className="panel">
                  <div className="panel-heading"><div><h3>Club priorities</h3><p className="muted">BOARD EXPECTATIONS</p></div><ClipboardList size={18}/></div>
                  <div className="priority-list">
                    {team.boardExpectations.map((item, i) => <div className="priority" key={item}><span className="priority-number">0{i+1}</span>{item}</div>)}
                  </div>
                </section>
              </div>

              <section className="panel squad-panel">
                <div className="panel-heading"><div><h3>First-team squad</h3><p className="muted">A QUICK LOOK AT YOUR PLAYERS</p></div><button className="text-button" onClick={() => setPage("Squad")}>View squad <ChevronRight size={15}/></button></div>
                <div className="player-list">
                  {squad.slice(0, 5).map(player => (
                    <div className="player-row" key={player.id}>
                      <div className="player-avatar">{player.name.split(" ").map(x=>x[0]).join("").slice(0,2)}</div>
                      <div className="player-name"><strong>{player.name}</strong><span>{player.position.join(" / ")} · {player.age} years</span></div>
                      <div className="player-rating">{player.overall}</div>
                      <div className="player-condition"><div><span style={{width:`${player.condition}%`}}/></div><small>{player.condition}% condition</small></div>
                    </div>
                  ))}
                </div>
              </section>
            </>
          ) : page === "Squad" ? (
            <section>
              <div className="welcome-row"><div><div className="eyebrow">FIRST TEAM</div><h1>Squad</h1><p className="muted">Player overview and squad depth.</p></div></div>
              <div className="panel">
                <div className="panel-heading"><h3>Players ({squad.length})</h3></div>
                {squad.map(p => <div className="player-row" key={p.id}><div className="player-avatar">{p.name.split(" ").map(x=>x[0]).join("").slice(0,2)}</div><div className="player-name"><strong>{p.name}</strong><span>{p.position.join(" / ")} · Age {p.age}</span></div><div className="player-rating">{p.overall}</div><div className="muted">Potential {p.potential}</div></div>)}
              </div>
            </section>
          ) : page === "Match Centre" ? (
            <section><div className="welcome-row"><div><div className="eyebrow">MATCH DAY</div><h1>Match centre</h1><p className="muted">A first look at the 2D match presentation.</p></div></div><div className="panel"><div className="panel-heading"><h3>Match preview</h3><span className="status-pill">DEMO PITCH</span></div><MatchPitch /></div></section>
          ) : (
            <section><div className="welcome-row"><div><div className="eyebrow">MANAGEMENT</div><h1>{page}</h1><p className="muted">This module is planned but not implemented yet.</p></div></div><div className="empty-state"><div className="empty-icon"><Settings size={24}/></div><h3>{page} module</h3><p>This screen is a placeholder for the next development phase. Ask Codex to implement it without breaking existing features.</p></div></section>
          )}
        </div>
      </main>
    </div>
  );
}

function Stat({icon: Icon, label, value, detail}) {
  return <div className="stat-card"><div className="stat-top"><span>{label}</span><Icon size={17}/></div><strong>{value}</strong><small>{detail}</small></div>;
}
function money(value) {
  return new Intl.NumberFormat("en-GB", {style:"currency",currency:"GBP",maximumFractionDigits:0}).format(value);
}
